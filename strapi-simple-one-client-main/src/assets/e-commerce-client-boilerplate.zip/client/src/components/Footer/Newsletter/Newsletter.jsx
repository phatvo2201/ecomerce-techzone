import "./Newsletter.scss";
const Newsletter = () => {
    return <div>Newsletter</div>;
};

export default Newsletter;
