import "./SingleProduct.scss";
const SingleProduct = () => {
    return <div>Single Product</div>;
};

export default SingleProduct;
