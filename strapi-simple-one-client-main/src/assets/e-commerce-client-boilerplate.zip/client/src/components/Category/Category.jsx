import "./Category.scss";
const Category = () => {
    return <div>Category</div>;
};

export default Category;
